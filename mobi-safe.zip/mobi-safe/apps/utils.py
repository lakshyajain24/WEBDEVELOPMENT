import json
import requests
import urllib.parse
import textwrap
from config import GEOCODING_URL, geocoding_req_params


def get_geocoding_options(search_query):
    if search_query:
        search_query = urllib.parse.quote(search_query)
        req_url = GEOCODING_URL.format(search_query)
        r = requests.get(req_url, params=geocoding_req_params)
        options = [{'label': textwrap.shorten(feature["place_name"], width=55, placeholder="..."), 'value': json.dumps(feature)} for feature in r.json()["features"]]
        return options
    else:
        return []
    

# response = get_geocoding_options("vaishali")

