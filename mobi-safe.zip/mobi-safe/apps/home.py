import dash_html_components as html
import dash_bootstrap_components as dbc


layout = html.Div([
    dbc.Container([
        dbc.Row([
            dbc.Col(html.H1("Welcome to the Mobility dashboard", className="text-center")
                    , className="mb-5 mt-5")
        ]),
        dbc.Row([
            dbc.Col(html.H5(children='Lorem Ipsum is simply dummy text of the printing and typesetting industry.'
                                     )
                    , className="mb-4")
            ]),

        dbc.Row([
            dbc.Col(html.H5(children='Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.')
                    , className="mb-5")
        ]),

        dbc.Row([

            dbc.Col(dbc.Card([dbc.CardHeader(html.H4('Read more about our work'),
                                               className="text-center",
                                       style={'height':'20vh'}),
                                       dbc.CardFooter(dbc.Button("Read more..",
                                                  href="https://mobility-web-deploy.herokuapp.com",
                                                  color="primary",
                                                  className="mt-3")),
                                                  
                                       ],
                             body=True, color="dark", outline=True)
                    ,),

            dbc.Col(dbc.Card([dbc.CardHeader(html.H4('Access the codeused to build this dashboard'),
                                       style={'height':'20vh'},
                                               className="text-center"),
                                       dbc.CardFooter(dbc.Button("GitHub",
                                                  href="https://mobility-web-deploy.herokuapp.com",
                                                  color="primary",
                                                  className="mt-3")),
                                       ],
                             body=True, color="dark", outline=True)
                    ,),

            dbc.Col(dbc.Card([dbc.CardHeader(html.H4('Check out demo'),
                                               className="text-center",
                                       style={'height':'20vh'}),
                                       dbc.CardFooter(dbc.Button("Demo",
                                                  href="https://mobility-web-deploy.herokuapp.com/trip-planner",
                                                  color="primary",
                                                  className="mt-3")),

                                       ],
                             body=True, color="dark", outline=True)
                    ,)
        ], className="mb-5"),

        html.A("Special thanks to University of Edinburgh for funding this project",
               href="https://www.ed.ac.uk/")

    ])

])


