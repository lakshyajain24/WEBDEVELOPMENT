import json
from dash_bootstrap_components._components.Row import Row
import dash_html_components as html
import dash_core_components as dcc
import dash_bootstrap_components as dbc
from dash.dependencies import Input, Output, State
import dash_deck
import pydeck as pdk
import pandas as pd

from IPython.display import display

import requests

from dash.exceptions import PreventUpdate

# raise PreventUpdate

from shapely.geometry import box, Point, shape

from app import app
from config import *
from .utils import get_geocoding_options
import pickle
import networkx as nx
import osmnx as ox

ox.config(use_cache=True, log_console=True)


delhi_boundary = [
    76.8388830269287,
    28.4042620003073,
    77.3464387601731,
    28.8835889894397,
]
delhi_bbox = box(
    delhi_boundary[0], delhi_boundary[1], delhi_boundary[2], delhi_boundary[3]
)
f = open("assets/path_finder/delhi_graph_data.pkl", "rb")
G = pickle.load(f)

COVID_HOTSPOTS_DATA = (
    # "https://sumit-mobility-web.s3.eu-west-2.amazonaws.com/covid_hotspots_delhi.csv"
    "assets/path_finder/new.csv"  # using the csv on which the weights of the path are calculated
)
covid_hotspots_df = None
covid_hotspots_view_state = None
covid_hotspots_view_layer = None
covid_hotspot_layer_tooltip = {"html": "{name}", "style": {"color": "white"}}


layout = dbc.Container(
    [
        dbc.Row(
            className="my-3",
            children=[
                dbc.Modal(
                    [
                        dbc.ModalHeader("Invalid location"),
                        dbc.ModalBody("Please enter a location inside Delhi"),
                        dbc.ModalFooter(
                            dbc.Button(
                                "Close", id="close", className="ml-auto", n_clicks=0
                            )
                        ),
                    ],
                    id="modal",
                    is_open=False,
                    centered=True,
                ),
                dbc.Col(
                    # style={"background-color": "red"},
                    className="mr-4",
                    children=[
                        dbc.Card(
                            dbc.CardBody(
                                [
                                    html.H4(
                                        className="my-2 mx-3", children="Trip Planner"
                                    ),
                                    html.P(
                                        className="my-4 mx-3",
                                        children=[
                                            """Select from and to location to plan your safe trip within Delhi"""
                                        ],
                                    ),
                                    html.P(
                                        "COVID hotspot and related routes are considered for an area of 30 * 30 km^2 centered at Latitude and Longitude of (28.612631, 77.204754). This is centre of New Delhi, India. ",
                                        className="my-4 mx-3",
                                    ),
                                    dbc.Form(
                                        className="mt-3",
                                        children=[
                                            dbc.FormGroup(
                                                [
                                                    dcc.Dropdown(
                                                        id="from_loc_dropdown",
                                                        style={"color": "black"},
                                                        className="my-4 mx-3",
                                                        placeholder="From location",
                                                        options=[],
                                                        searchable=True,
                                                        clearable=True,
                                                    ),
                                                    dcc.Dropdown(
                                                        id="to_loc_dropdown",
                                                        style={"color": "black"},
                                                        className="my-4 mx-3",
                                                        placeholder="To location",
                                                        options=[],
                                                        searchable=True,
                                                        clearable=True,
                                                    ),
                                                    dbc.Checklist(
                                                        options=[
                                                            {
                                                                "label": "Show path avoiding covid hotspots",
                                                                "value": 0,
                                                            },
                                                        ],
                                                        value=0,
                                                        id="avoid-hotspot-input",
                                                        className="mx-3",
                                                    ),
                                                ]
                                            )
                                        ],
                                    ),
                                    dbc.FormGroup(
                                        [
                                            dbc.Label("Layers", className="mx-3"),
                                            dbc.Checklist(
                                                options=[
                                                    {
                                                        "label": "Covid hotspots in Delhi",
                                                        "value": 1,
                                                    },
                                                ],
                                                value=[1],
                                                id="layer-switches-input",
                                                switch=True,
                                                className="mx-3",
                                            ),
                                        ]
                                    ),
                                    dbc.Row(
                                        justify="center",
                                        children=[
                                            dbc.Button(
                                                "Plan Routes",
                                                id="plan-routes-button",
                                                color="primary",
                                                size="lg",
                                                className="my-3",
                                            )
                                        ],
                                    ),
                                ]
                            ),
                            className="mt-3",
                        ),
                    ],
                ),
                dbc.Col(
                    className="my-3 p-3",
                    width=12,
                    lg=6,
                    children=[
                        dbc.Spinner(html.Div(id="trips-map-loading"), color="success"),
                    ],
                ),
            ],
        )
    ]
)


@app.callback(
    Output("modal", "is_open"),
    [
        Input("from_loc_dropdown", "value"),
        Input("to_loc_dropdown", "value"),
        Input("close", "n_clicks"),
    ],
    [State("modal", "is_open")],
)
def check_from_loc_modal(from_loc_value, to_loc_value, close_n_clicks, is_open):
    if close_n_clicks >= 1 and is_open:
        return False
    not_in_region = False
    from_loc_point = get_loc_point_from_dropdown(from_loc_value)
    if from_loc_point:
        not_in_region = not delhi_bbox.contains(from_loc_point)
    to_loc_point = get_loc_point_from_dropdown(to_loc_value)
    if to_loc_point:
        not_in_region = not delhi_bbox.contains(to_loc_point)
    return not_in_region


@app.callback(
    Output("from_loc_dropdown", "options"),
    [Input("from_loc_dropdown", "search_value"), State("from_loc_dropdown", "options")],
)
def update_from_loc_options(search_query, options):
    return options + get_geocoding_options(search_query)


@app.callback(
    Output("to_loc_dropdown", "options"),
    [Input("to_loc_dropdown", "search_value"), State("to_loc_dropdown", "options")],
)
def update_to_loc_options(search_query, options):
    return options + get_geocoding_options(search_query)


@app.callback(
    Output("trips-map-loading", "children"),
    [
        Input("layer-switches-input", "value"),
        Input("avoid-hotspot-input", "value"),
        Input("plan-routes-button", "n_clicks"),
        Input("from_loc_dropdown", "value"),
        Input("to_loc_dropdown", "value"),
    ],
)
def load_output(layer_selections, avoid_covid, n_clicks, from_loc_value, to_loc_value):
    layers = []

    show_covid_hotspots = len(layer_selections) > 0 and 1 in layer_selections
    view_state, covid_hotspots_layer = get_covid_hotspots_layer()
    if show_covid_hotspots:
        layers.append(covid_hotspots_layer)

    if n_clicks and n_clicks > 0:
        from_loc_point = get_loc_point_from_dropdown(from_loc_value)
        to_loc_point = get_loc_point_from_dropdown(to_loc_value)
        if from_loc_point and to_loc_point:
            from_loc_name = get_loc_name_from_dropdown(from_loc_value)
            to_loc_name = get_loc_name_from_dropdown(to_loc_value)
            text_layer = get_text_layer(
                from_loc_point, from_loc_name, to_loc_point, to_loc_name
            )
            trips_layer, center_point, distance, duration = get_trips_layer(
                from_loc_point, to_loc_point
            )
            if avoid_covid:
                avoid_covid_layer, avoid_covid_distance = get_trips_layer_avoid_covid(
                    from_loc_point, to_loc_point
                )
                layers.append(avoid_covid_layer)
            if trips_layer:
                layers.append(trips_layer)
                layers.append(text_layer)
                view_state = pdk.ViewState(
                    latitude=center_point.y,
                    longitude=center_point.x,
                    zoom=13,
                    bearing=0,
                    pitch=45,
                )
                # TODO: Show distance, duration too.

    # Render
    if len(layers) > 1:
        view_state.zoom = 13
    layer_data = pdk.Deck(layers=layers, initial_view_state=view_state)

    deck_gl_map = dash_deck.DeckGL(
        layer_data.to_json(),
        id="trips-map-graph",
        mapboxKey=MAPBOX_ACCESS_TOKEN,
        style={"height": "80vh"},
    )

    if show_covid_hotspots:
        deck_gl_map.tooltip = covid_hotspot_layer_tooltip

    return deck_gl_map


def get_trips_layer(from_loc_point, to_loc_point):

    coords_str = (
        f"{from_loc_point.x},{from_loc_point.y};{to_loc_point.x},{to_loc_point.y}"
    )
    req_url = DIRECTIONS_URL.format(coords_str)
    r = requests.get(req_url, params=directions_req_params)
    response = r.json()["routes"]

    if len(response) > 0:

        directions = []
        distance = response[0]["distance"]
        duration = response[0]["duration"]
        coordinates = response[0]["geometry"]["coordinates"]
        num_coordinates = len(coordinates)

        center_point = shape(response[0]["geometry"]).centroid

        timestamps = []
        count = 0
        for i in range(num_coordinates):
            timestamps.append(count)
            count += duration // num_coordinates

        directions.append({"coordinates": coordinates, "timestamps": timestamps})

        directions_df = pd.DataFrame(directions)

        trips_layer = pdk.Layer(
            "TripsLayer",
            directions_df,
            get_path="coordinates",
            # get_timestamps="timestamps",
            get_color=[253, 128, 93],
            opacity=1.0,
            width_min_pixels=5,
            # rounded=True,
            # trail_length=timestamps[-1],
            # current_time=timestamps[-1],
        )

        return trips_layer, center_point, distance, duration

    return [], None, 0, 0


def get_text_layer(from_loc_point, from_loc_name, to_loc_point, to_loc_name):
    texts = {}
    texts["coordinates"] = [
        [from_loc_point.x, from_loc_point.y],
        [to_loc_point.x, to_loc_point.y],
    ]
    texts["name"] = [" ".join(from_loc_name.split()), " ".join(to_loc_name.split())]
    df = pd.DataFrame(texts)
    return pdk.Layer(
        "TextLayer",
        df,
        pickable=True,
        get_position="coordinates",
        get_text="name",
        get_size=16,
        get_color=[255, 255, 255],
        get_angle=0,
        # Note that string constants in pydeck are explicitly passed as strings
        # This distinguishes them from columns in a data set
        get_text_anchor="'middle'",
        get_alignment_baseline="'center'",
    )


def get_covid_hotspots_layer():
    global covid_hotspots_df, covid_hotspots_view_state, covid_hotspots_view_layer
    if covid_hotspots_df is None:
        covid_hotspots_df = pd.read_csv(COVID_HOTSPOTS_DATA)
        covid_hotspots_view_state = pdk.data_utils.compute_view(
            covid_hotspots_df[["lng", "lat"]]
        )
        covid_hotspots_view_state.zoom = 10
        covid_hotspots_view_layer = pdk.Layer(
            "ScatterplotLayer",
            covid_hotspots_df,
            pickable=True,
            opacity=0.8,
            filled=True,
            radius_scale=6,
            radius_min_pixels=1,
            radius_max_pixels=100,
            line_width_min_pixels=1,
            get_position=["lng", "lat"],
            get_radius=40,
            get_fill_color=[239, 0, 83, 80],
            get_line_color=[0, 0, 0],
        )
    return covid_hotspots_view_state, covid_hotspots_view_layer


def get_loc_point_from_dropdown(loc_value):
    if loc_value:
        loc_dict = json.loads(loc_value)
        loc_center = loc_dict["center"]
        return Point(loc_center[0], loc_center[1])
    return None


def get_loc_name_from_dropdown(loc_value):
    if loc_value:
        loc_dict = json.loads(loc_value)
        return loc_dict["place_name"]
    return None


def get_trips_layer_avoid_covid(from_loc_point, to_loc_point):

    origin = ox.nearest_nodes(G, from_loc_point.x, from_loc_point.y)
    destination = ox.nearest_nodes(G, to_loc_point.x, to_loc_point.y)
    route_by_Weigh = nx.shortest_path(
        G, source=origin, target=destination, weight="Weigh"
    )

    directions = []
    coordinates = []

    for node in route_by_Weigh:
        coordinates.append([G.nodes[node]["x"], G.nodes[node]["y"]])

    directions.append({"coordinates": coordinates})

    directions_df = pd.DataFrame(directions)

    distance = int(
        sum(ox.utils_graph.get_route_edge_attributes(G, route_by_Weigh, "length"))
    )

    trips_layer = pdk.Layer(
        "TripsLayer",
        directions_df,
        get_path="coordinates",
        get_color=[124, 252, 0],
        opacity=1.0,
        width_min_pixels=5,
        rounded=True,
    )

    return trips_layer, distance
