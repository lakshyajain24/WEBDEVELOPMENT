import dash_html_components as html
import dash_bootstrap_components as dbc


layout = html.Div(
    [
        dbc.Container(
            [
                dbc.Row(
                    [
                        dbc.Col(
                            html.H1("About Us", className="text-center"),
                            className="mb-5 mt-5",
                        )
                    ]
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            html.H3(
                                "Increasing safety and sustainability of micro-mobility modes in pandemic",
                                className="text-center",
                            ),
                            className="mb-5 mt-5",
                        )
                    ]
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            html.H5(
                                "AIMS/GOALS:",
                            ),
                            className="mb-4 font-weight-bold",
                        )
                    ]
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            html.P(
                                children="""In this time of pandemic COVID 19 public vehicles like buses, metro, and vehicle sharing services cease to exist
                                        or if available in lockdown relief, people are reluctant to use it. This situation left users with a limited choice of
                                        using personal vehicles which in turn escalated traffic by many folds despite the reduction in long-distance commute.
                                        To avoid traffic, for small distances within a few kilometers many users may intend to choose either cycling or walking.
                                        For facilitating safe commute authorities are creating bike lanes and walkways so residents can practice physical distancing
                                        while being able to commute in their locality. UK cycle-to-work schemes are up 200% in the number of bicycle orders and
                                        major cities like Paris are looking to redesign their neighborhood to avail amenities within 15-minute walk or bike ride.
                                        According to the World Bank, nearly 300 cities and regions have implemented people-friendly streets initiatives that allow
                                        residents to bike and walk within their city. In Europe, for example, almost 2,400 Km of cycling infrastructure has been
                                        announced by various levels of governments as of August 5, 2020. In the coming years, people will need to adapt to physical
                                        distancing, and municipal authorities will likely expand on recent measures to develop biking and walking infrastructure
                                        as a way to promote more live able, sustainable, and accessible cities. As a result, urban mobility will likely see an
                                        uptake in shared micro-mobility with residents selectively choosing when to take public transportation."""
                            ),
                            className="mb-4",
                        )
                    ]
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            html.P(
                                children="""However, choosing these modes can have their cons and pros. In opposite to car and motorcycle where people are
                                        safe in the enclosed environment of car or by wearing helmets on motorcycles, cycling and walking left them exposed
                                        to the external environment. Further traveling via a cycle that is small enough to fit any place or just walking in a
                                        given street can provoke the rider to find a short-cut by going inside small narrow lanes. However again user might
                                        be unaware of the situation of the infection in that area and containment zones, hence rerouting can introduce them
                                        to the virus. Moreover, COVID 19 virus can be active as long as 3 days on different surfaces so surface contacts of
                                        shoes while cycling and walking make the user potential carrier of the virus to their living places. With these facts
                                        surfaced and the fact that travel and commute can be inevitable at times, safe route planning for cycling and walking
                                        is extremely important for the safety of oneself and others. Similarly the rising demand in these modes and to fulfil
                                        it government need to measure and facilitate it accordingly. This shows that in this time of pandemic commute needs
                                        to be tackled more smartly and better and new facilitation according to needs."""
                            ),
                            className="mb-5",
                        )
                    ]
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            html.H5(
                                "APPROACH:",
                            ),
                            className="mb-4 font-weight-bold",
                        )
                    ]
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            html.P(
                                children="""Hence, we propose a multi-criteria route planning technique for cyclists and pedestrians. This aims at objectively
                                        determining the routes based on various criteria about the safety of a given route while keeping the user away from potential
                                        COVID-19 transmission spots. The vulnerable spots include places such as a hospital or medical facilities, contained
                                        residential areas, and roads with high connectivity and influx of people. Our proposed algorithm returns a multi-criteria
                                        route modeled by considering safety as well as the shortest route for user ease and short time of outside environment
                                        exposure. So first we visualize containment zones and medical facilities in a region. We will define parameters pertaining
                                        to user facilitation in terms of safety, amenity reach and mobility ease using the walking and cycling modes. This
                                        visualization can help authorities to facilitate these modes by planning bike and walking lanes. Further, necessary amenities
                                        can be availed for remote areas in terms of cycling distance. Next for safe commute our portal will suggest safe route for
                                        walking and bicycling to user. For web portal, Technology adopted will be Server architect deployment on Cloud - [AWS],
                                        Backend for algorithm and system design - [using Python & Nodejs], Frontend for user panel and status of different
                                        parameters [HTML & ReactJS], GIS APIs subscription- [Google Maps, Bing Maps, TOM TOM, HERE map]. Data
                                        Requirements may be of land use spatial data through APIs."""
                            ),
                            className="mb-5",
                        )
                    ]
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            html.H5(
                                "OUTPUTS:",
                            ),
                            className="mb-4 font-weight-bold",
                        )
                    ]
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            html.P(
                                children=[
                                    """The developed system will be accessible to users via a website as well as it is viable to provide an app. The
                                        visualization will be on a map [1] for the safe path to be taken by a user dynamically updated and in real-time (Figure
                                        1a, 1b). The product is going to run an algorithm that design for safe route searching using data acquired from civic
                                        authorities and other spatial data providers mentioned in the previous section. Further, so the municipal portal can use
                                        it in their own portal, if they want, the whole source-code can be open sourced like the Google and Apple open source
                                        architecture [2] for contact tracing. The visualisations [1, 3] would also be based on zones of various levels of restricted
                                        movements like red zone, orange zone, yellow zone, green zone. The contributions are: web-map, Portal,
                                        algorithm/architecture. Using the service user can use real time (not only static) path guidance from our website.
                                        Research Paper- Application-Based COVID-19 Micro-Mobility Solution for Safe and Smart Navigation in Pandemics
                                        S Mishra, N Singh, D Bhattacharya, ISPRS International Journal of Geo-Information, 2021, 10 (8), 571, """,
                                    html.A(
                                        "https://www.mdpi.com/2220-9964/10/8/571/htm",
                                        href="https://www.mdpi.com/2220-9964/10/8/571/htm",
                                        target="_blank",
                                    ),
                                ]
                            ),
                            className="mb-5",
                        )
                    ]
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            html.H5(
                                "TEAM MEMBERS:",
                            ),
                            className="mb-4 font-weight-bold",
                        )
                    ]
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            dbc.Card(
                                [
                                    dbc.CardHeader(
                                        html.Img(
                                            src="assets/devanjan.png",
                                            className="card-img-top",
                                        ),
                                    ),
                                    dbc.CardFooter(
                                        dbc.Col(
                                            [
                                                html.H4("Dr. Devanjan Bhattacharya"),
                                                html.Br(),
                                                html.P(
                                                    """Marie Skłodowska-Curie Actions
                                                        TRAIN@ED Fellow, Data Driven
                                                        Innovation (DDI) Initiative Edinburgh,
                                                        School of Law, and, School of Informatics,
                                                        University of Edinburgh, Old College,
                                                        South Bridge, EH8 9YL Edinburgh, United
                                                        Kingdom."""
                                                ),
                                                html.Br(),
                                                html.A(
                                                    "https://www.law.ed.ac.uk/people/dr-devanjan-bhattacharya",
                                                    href="https://www.law.ed.ac.uk/people/dr-devanjan-bhattacharya",
                                                ),
                                                html.Br(),
                                                html.P("Role- Principal Investigator"),
                                            ],
                                        ),
                                        className="text-center",
                                    ),
                                ],
                                body=True,
                                color="dark",
                                outline=True,
                            ),
                            className="mb-5",
                        ),
                        dbc.Col(
                            dbc.Card(
                                [
                                    dbc.CardHeader(
                                        html.Img(
                                            src="assets/sumit.png",
                                            className="card-img-top",
                                        ),
                                    ),
                                    dbc.CardFooter(
                                        dbc.Col(
                                            [
                                                html.H4("Sumit Mishra"),
                                                html.Br(),
                                                html.P(
                                                    """The Robotics Program,
                                                        Korea Advanced Institute of Science and
                                                        Technology,
                                                        Daejeon 34141, Republic of Korea"""
                                                ),
                                                html.Br(),
                                                html.A(
                                                    "https://sumitmishra209.wixsite.com/mysite",
                                                    href="https://sumitmishra209.wixsite.com/mysite",
                                                ),
                                                html.Br(),
                                                html.P("Role- Research Consultant"),
                                            ],
                                        ),
                                        className="text-center",
                                    ),
                                ],
                                body=True,
                                color="dark",
                                outline=True,
                            ),
                            className="mb-5",
                        ),
                    ],
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            dbc.Card(
                                [
                                    dbc.CardHeader(
                                        html.Img(
                                            src="assets/atanshi.png",
                                            className="card-img-top",
                                        ),
                                    ),
                                    dbc.CardFooter(
                                        dbc.Col(
                                            [
                                                html.H4("Atanshi Chaturvedi"),
                                                html.Br(),
                                                html.P(
                                                    """Data Analyst, The Smart Cube
                                                        Noida, Uttar Pradesh 201301, India"""
                                                ),
                                                html.Br(),
                                                html.P("Role- Research Intern"),
                                            ],
                                        ),
                                        className="text-center",
                                    ),
                                ],
                                body=True,
                                color="dark",
                                outline=True,
                            ),
                            className="mb-5",
                        ),
                        dbc.Col(
                            dbc.Card(
                                [
                                    dbc.CardHeader(
                                        html.Img(
                                            src="assets/nikhil.png",
                                            className="card-img-top",
                                        ),
                                    ),
                                    dbc.CardFooter(
                                        dbc.Col(
                                            [
                                                html.H4("Nikhil Singh"),
                                                html.Br(),
                                                html.P(
                                                    """Department of Information Technology,
                                                        Manipal University Jaipur, Rajasthan
                                                        303007, India"""
                                                ),
                                                html.Br(),
                                                html.P("Role- Research Intern"),
                                            ],
                                        ),
                                        className="text-center",
                                    ),
                                ],
                                body=True,
                                color="dark",
                                outline=True,
                            ),
                            className="mb-5",
                        ),
                    ],
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            html.H5(
                                "Acknowledgment:".upper(),
                            ),
                            className="mb-4 font-weight-bold",
                        )
                    ]
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                html.P(
                                    children=[
                                        """The work has been a part of the project “Increasing safety and sustainability of micro-mobility modes in pandemic—
                                        MobilitySafe” funded by UKRI ESRC Impact acceleration grant, University of Edinburgh (grant reference
                                        ES/T50189X/1) and Devanjan Bhattacharya has received funding from the European Union's Horizon 2020 research
                                        and innovation programme under the Marie Skłodowska-Curie COFUND grant agreement No. 801215: TRAIN@Ed:
                                        'Transnational Research And Innovation Network At Edinburgh', and the Edinburgh and South East Scotland City
                                        Region Deal Data-Driven Innovation Initiative. """,
                                    ]
                                ),
                                html.P(
                                    children=[
                                        "Industrial support to the project and the letter of support for data sharing was issued to Sumit Mishra by GIZ, India.",
                                    ]
                                ),
                                html.Img(src="assets/uni.png", className="w-50 mb-5"),
                                html.P(
                                    children=[
                                        "The University of Edinburgh is a charitable body, registered in Scotland, with registration number SC005336. Is ebuidheann carthannais a th’ ann an Oilthigh Dhùn Èideann, clàraichte an Alba, àireamh clàraidh SC005336"
                                    ]
                                ),
                                html.Img(src="assets/giz.png", className="w-50"),
                            ],
                            className="mb-5",
                        )
                    ]
                ),
            ]
        )
    ]
)
