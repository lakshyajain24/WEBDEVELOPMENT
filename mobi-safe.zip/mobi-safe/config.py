MAPBOX_ACCESS_TOKEN = "pk.eyJ1IjoiZGV2YW5qYW4iLCJhIjoiY2x0OGw0ZWltMHY3MzJtcXV4emFiNjRhMyJ9.xO4fKfx1HAQK72jnZgyrvw"

GEOCODING_URL = "https://api.mapbox.com/geocoding/v5/mapbox.places/{}.json"
DIRECTIONS_URL = "https://api.mapbox.com/directions/v5/mapbox/walking/{}"

geocoding_req_params = {'access_token': MAPBOX_ACCESS_TOKEN}
directions_req_params = {'access_token': MAPBOX_ACCESS_TOKEN, 'geometries': "geojson", 'steps': "false"}