# from flask import Flask
# from flask_wtf.csrf import CSRFProtect

import dash
import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc

# from whitenoise import WhiteNoise

from dash.dependencies import Input, Output, State


# flask_app = Flask(__name__)
# flask_app.wsgi_app = WhiteNoise(flask_app.wsgi_app, root='static/')

# csrf = CSRFProtect(flask_app)

# flask_app.config['SECRET_KEY'] = ' hudqwvgywvcgvwyvdbuyq@#jcw'

# csrf._exempt_views.add('dash.dash.dispatch')


external_stylesheets = [dbc.themes.DARKLY]

app = dash.Dash(
    __name__,
    meta_tags=[
        {"name": "viewport", "content": "width=device-width", "initial-scale": 1}
    ],
    external_stylesheets=external_stylesheets,
)

app.title = "Moblity Dashboard"

server = app.server

app.config.suppress_callback_exceptions = True


dropdown = dbc.DropdownMenu(
    children=[
        dbc.DropdownMenuItem("Home", href="/home"),
        dbc.DropdownMenuItem("Trip Planner", href="/trip-planner"),
        dbc.DropdownMenuItem("Bike Trips", href="/bike-trips"),
        dbc.DropdownMenuItem("Bikebility", href="/bike-index"),
        dbc.DropdownMenuItem("Bike Use-Case", href="/bike-uk"),
        dbc.DropdownMenuItem("Jobs Visualization", href="/jobs"),
        dbc.DropdownMenuItem("About Us", href="/about"),
    ],
    nav=True,
    in_navbar=True,
    label="Explore",
)

navbar = dbc.Navbar(
    dbc.Container(
        [
            html.A(
                # Use row and col to control vertical alignment of logo / brand
                dbc.Row(
                    [
                        dbc.Col(html.Img(src="/assets/logo.png", height="40px")),
                        dbc.Col(
                            dbc.NavbarBrand("Mobility Dashboard", className="ml-2")
                        ),
                    ],
                    align="center",
                    no_gutters=True,
                ),
                href="/home",
            ),
            dbc.NavbarToggler(id="navbar-toggler2"),
            dbc.Collapse(
                dbc.Nav(
                    # right align dropdown menu with ml-auto className
                    [dropdown],
                    className="ml-auto",
                    navbar=True,
                ),
                id="navbar-collapse2",
                navbar=True,
            ),
        ]
    ),
    color="dark",
    dark=True,
    className="mb-4",
)


def toggle_navbar_collapse(n, is_open):
    if n:
        return not is_open
    return is_open


for i in [2]:
    app.callback(
        Output(f"navbar-collapse{i}", "is_open"),
        [Input(f"navbar-toggler{i}", "n_clicks")],
        [State(f"navbar-collapse{i}", "is_open")],
    )(toggle_navbar_collapse)

# embedding the navigation bar
app.layout = html.Div(
    [dcc.Location(id="url", refresh=False), navbar, html.Div(id="page-content")]
)


@app.callback(Output("page-content", "children"), [Input("url", "pathname")])
def display_page(pathname):
    # import all pages in the app
    from apps import (
        trip_planner,
        bike_trips,
        bike_rentals,
        bike_index,
        bike_uk,
        jobs,
        about,
        home,
    )

    if pathname == "/trip-planner":
        return trip_planner.layout
    elif pathname == "/bike-trips":
        return bike_trips.layout
    elif pathname == "/bike-rentals":
        return bike_rentals.layout
    elif pathname == "/bike-index":
        return bike_index.layout
    elif pathname == "/bike-uk":
        return bike_uk.layout
    elif pathname == "/jobs":
        return jobs.layout
    elif pathname == "/about":
        return about.layout
    else:
        return home.layout
